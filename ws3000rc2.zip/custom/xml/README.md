This directory is for custom xml feeds. These are "actions" which are loaded by the XmlController automatically. Please see our online documentation on the proper way to build a custom XML feed.
