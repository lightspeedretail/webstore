This directory is for custom models. If you have added tables to your database, you will need to run giix to generate the model files and you can place them here.

See our online developer help on how to perform that process.