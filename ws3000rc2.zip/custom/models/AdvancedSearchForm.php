<?php

//For extending advanced search if necessary

class AdvancedSearchForm extends BaseAdvancedSearchForm
{

}
