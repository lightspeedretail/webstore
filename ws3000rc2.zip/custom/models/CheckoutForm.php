<?php

//For extending checkout model if necessary

class CheckoutForm extends BaseCheckoutForm
{

}
