This directory is for custom controllers as well as overriding controllers (though we don't recommend overriding existing controllers).

For documentation on how to do this, see our online Web Store programming help under Creating a custom controller