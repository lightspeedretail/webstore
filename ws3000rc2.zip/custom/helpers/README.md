This directory is for custom helpers (PHP classes). Note that the filename should match the class name, so Yii will automatically find the class file. For example, a file that begins:

class MyImageManager {

should have a file name of MyImageManager.php

